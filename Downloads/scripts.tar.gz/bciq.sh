#!/bin/bash

method="$1"
IP="$2"
# replace IP-ADDRESS with your vpn private IP or public IP
addr="http://${IP}:8003"
if [ "$method" == "invoke" ];then
  curl -XPOST ${addr}/api/v1/blockchain/invoke  -d@invoke.json; echo
elif [ "$method" == "query" ]; then
  curl -XPOST ${addr}/api/v1/blockchain/query  -d@query.json; echo
elif [ "$method" == "querytxn" ]; then
  curl -XPOST ${addr}/api/v1/blockchain/transaction/"$3"; echo
else
  echo "invalid method, must be one of [query,invoke,querytxn]."
  exit -1
fi
